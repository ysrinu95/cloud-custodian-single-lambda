class MetricType:
    COUNT = "c"
    GAUGE = "g"
    SET = "s"
    HISTOGRAM = "h"
    DISTRIBUTION = "d"
    TIMING = "ms"
